var win = true;

if (win) {
  console.log("MI will win");
}

if (!win) {
  console.log("RCB will win");
}
