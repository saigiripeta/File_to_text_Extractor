var win = false;
if (x > 2) {
  console.log("MI");
} else {
  console.log("RCB");
}
