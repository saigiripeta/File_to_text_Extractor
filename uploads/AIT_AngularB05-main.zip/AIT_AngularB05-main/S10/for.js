for (var x = 51; x <= 79; x++) {
  if (x % 2 != 0) {
    console.log(x);
  }
}
