var x = "sun";

switch (x) {
  case "mon":
    console.log("Today is Monday");
    break;
  case "tue":
    console.log("Today is Tuesday");
  default:
    console.log("value is not matching");
}
