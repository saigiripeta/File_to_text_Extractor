var city;

city = "hyd";

city = 1234;

city = true;

//dynamic typed or loosely typed Programming Language
