var myCity:string = "hyd";

const pinnumber:number = 123;

let gender:string = "male"

gender="female"
myCity = "Pune"

console.log(myCity,pinnumber,gender)