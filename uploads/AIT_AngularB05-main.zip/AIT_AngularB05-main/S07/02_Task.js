var myCity = "hyd";
var pinnumber = 123;
var gender = "male";
gender = "female";
myCity = "Pune";
console.log(myCity, pinnumber, gender);
