var cityName:string ;
cityName = "hyd"

// cityName = 123 invalid


var pin = 123;

// pin = "kdsjbcdjksbc" invalid

//Strongly typed or static typed Programming Language

