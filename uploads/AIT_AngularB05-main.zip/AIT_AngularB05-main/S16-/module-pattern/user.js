export var username = "Raj Verma"; //named export

export function f1() {
  console.log("f1 is called");
  console.log(username);
}
