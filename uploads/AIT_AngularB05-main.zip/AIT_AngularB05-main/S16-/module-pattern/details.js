import { username, f1 } from "./user.js";

import Ref from "./Products.js";

console.log(username);

f1();
Ref();
