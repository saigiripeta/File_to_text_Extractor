export var product = {
  name: "iphone 16",
  price: 90000,
};

function displayProduct() {
  console.log(product);
}
function f1() {
  console.log("f1");
}

export default displayProduct;
