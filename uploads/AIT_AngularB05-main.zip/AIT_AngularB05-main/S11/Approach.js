function f1() {
  var x = 10;
  var y = 20;
  var z;
  z = x + y;
  console.log(z);
}

f1();
