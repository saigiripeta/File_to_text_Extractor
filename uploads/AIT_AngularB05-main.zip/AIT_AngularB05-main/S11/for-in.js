var obj = {
  name: "sagar",
  id: 101,
  gender: "male",
  city: "pune",
};

for (var key in obj) {
  console.log(obj[key]);
}
