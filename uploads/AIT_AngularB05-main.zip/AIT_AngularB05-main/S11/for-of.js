var arr = [10, 20, 30, 40, 50, "djkfnd", true, "djbfcdjk"];

for (var x of arr) {
  if (typeof x === "number") {
    console.log(x);
  }
}
