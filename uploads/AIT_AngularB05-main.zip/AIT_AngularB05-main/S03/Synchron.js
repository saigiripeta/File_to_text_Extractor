var x = 10;

var y;

let y = 100;

const pin = 123;

var phone = 99999;
