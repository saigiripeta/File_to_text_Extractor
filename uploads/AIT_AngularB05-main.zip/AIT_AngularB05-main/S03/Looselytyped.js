var city = "hyderabad";

city = "Pune";

city = 55;

city = true;
