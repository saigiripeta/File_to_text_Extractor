var x = "hyderabad";

var x = "pune"; //Re declaration is called shadowing

// let y = 123

// let y = 8989

// const pin = 89

// const pin = 89
