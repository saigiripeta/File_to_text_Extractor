var x = 10;

var y = 20;

var result = x + y;

console.log(result);

var x = 10;

var y = 20;

var result = x + y;

console.log(result);

var x = 10;

var y = 20;

var result = x + y;

console.log(result);
