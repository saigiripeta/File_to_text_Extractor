var username; //variable declaration

username = "Kabir"; //Assignment

username = "Riya"; //Re-assignment

let city; //variable declaration

var gender = "male"; //Initialization
