function getUsers() {
  var x = 10;

  var y = 20;

  var result = x + y;

  console.log(result);
}

getUsers(); // function call //10 20
getUsers(); //50 100
getUsers(); // 40 70
