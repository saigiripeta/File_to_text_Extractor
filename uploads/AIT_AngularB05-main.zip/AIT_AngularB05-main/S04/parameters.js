function getUsers(value1, value2) {
  var x = value1;

  var y = value2;

  var result = x + y;

  console.log(result);
}

getUsers(30, 80);
getUsers(40, 90);
getUsers(10, 20);
