var x = [10,20,30]

// var y:number[] =[10,20,30]

var names:string[] = ["s","a","g"]

var info:any[] = [100,200,"cdbc"]

var mystatus:boolean = false

let pin = 1234

// pin = "dckjcvjdkfnvdjkf"

var cities:any = "hyd"

cities = 999

cities = true

var y : string | number | boolean = 100

y = "cdhskdk"

y = true 

var a :"sagar" ="sagar"
 
var b:100 ;

b = 100

var infoData : [string,number] ;//tuple type
infoData =["s",1000]


// a = "aditya"

// a = 1000

