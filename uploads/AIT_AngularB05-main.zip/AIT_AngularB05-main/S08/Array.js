var data = [10, 20, 30];

//Object

var value = typeof data;
console.log(value);

var x = null;
console.log(typeof x);

var fn = function () {
  console.log("fn is called");
};

console.log(typeof fn);
