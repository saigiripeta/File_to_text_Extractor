function f1(){
    console.log("f1 is called")
    return true
}

var x = f1()
console.log(x)