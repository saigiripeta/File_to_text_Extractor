var x = 10; //10
var result = ++x + x++ + x-- + --x;
//  11 + 11 +12 + 10
var a = 10;
var b = 20;
var finalResult = a < b;
console.log(x); //    
console.log(result);
console.log(finalResult);
