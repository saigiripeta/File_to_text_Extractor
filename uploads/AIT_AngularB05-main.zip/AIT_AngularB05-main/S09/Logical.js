var x = 10;
var y = 20;
var z = 30;

var result = x > y && x < z;
console.log(result);
