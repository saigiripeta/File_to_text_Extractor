var x = 10;
var y = 20;

x += y; // x = x + y;
y += x; // y = y + x;
