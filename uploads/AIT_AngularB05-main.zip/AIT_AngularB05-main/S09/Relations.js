// var x = 1; //number

// var y = "1"; //boolean --- number

// var r = x - y;
// console.log(r);

var x = true;

var y = false;

console.log(x != y);
