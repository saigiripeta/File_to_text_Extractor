var x = 10; // number
var y = "10"; // string
var r = x == y;
