var x = 10  // number

var y = "10" // string

//  let r = x == y