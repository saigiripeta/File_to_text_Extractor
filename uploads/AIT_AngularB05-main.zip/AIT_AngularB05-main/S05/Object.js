var user = {}; // empty object
//Liternal Notation

console.log(user);

let product = {
  brand: "Apple",
  model: "Iphone 16",
  rating: 4.8,
  price: 90000,
};
console.log(product);
