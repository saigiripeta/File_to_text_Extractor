var user = {
  name: "Riya Sharma",
  email: "riya@gmail.com",
  gender: "female",
  phone: 1234567,
};

var emailValue = user.email;
console.log(emailValue);

var phoneValue = user["phone"];
console.log(phoneValue);
