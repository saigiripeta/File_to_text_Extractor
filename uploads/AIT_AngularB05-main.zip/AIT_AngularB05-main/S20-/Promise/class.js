class User {
  name = "sagar";
}

var u1 = new User();

console.log(u1);
