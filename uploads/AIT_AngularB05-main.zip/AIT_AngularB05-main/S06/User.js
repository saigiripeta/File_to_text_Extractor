var user = {
  name: "Rithvik",
  gender: "male",
  email: "r07@gmail.com",
  phone: 999999,
  fn: () => {
    console.log("fn is called");
  },
};

user.fn();

console.log();
