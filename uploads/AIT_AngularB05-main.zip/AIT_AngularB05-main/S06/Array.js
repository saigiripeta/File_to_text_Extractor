var data = [
  10,
  20,
  true,
  "pune",
  { price: 4000 },
  function f1() {
    console.log("f1 is called");
  },
];

console.log(data);
