import React from "react";

function Products() {
  return (
    <div style={{ color: "blue", padding: "50px" }}>
      <h2>Products Component</h2>
      <p>
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maxime soluta
        cum magni, cupiditate corrupti sint vitae, asperiores deleniti nisi vel
        tempore porro itaque natus possimus rerum culpa exercitationem suscipit
        est, harum praesentium quaerat laborum ut reprehenderit voluptatem!
        Dolor, itaque? Dolore, quasi! Odio quisquam eius facilis in sequi optio
        id accusantium, modi pariatur ab atque corrupti voluptatem
        exercitationem, natus perferendis eveniet quasi odit reprehenderit earum
        necessitatibus beatae consectetur vitae minima aspernatur! Vero quam
        iure doloremque, labore inventore amet explicabo nesciunt dolorum
        aliquam reiciendis architecto quas consectetur, perferendis non odio
        delectus unde quia? Aliquid facere inventore molestias qui odio, unde
        reiciendis accusantium?
      </p>
    </div>
  );
}

export default Products;
