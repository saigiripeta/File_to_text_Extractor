import React from "react";

function Home() {
  return (
    <div style={{ color: "green", padding: "50px" }}>
      <h2>Home Component</h2>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam, autem
        similique. Sed aspernatur eaque molestias ipsum! Aliquid commodi quod
        eius, nam minima molestiae. Saepe hic dolores deserunt. Ad expedita
        dolores velit dolor eius dicta placeat inventore temporibus. Voluptatem
        totam officia cumque maiores est. Provident tenetur numquam excepturi
        laborum dolore? Voluptates, minima. Pariatur laborum dolor voluptatem.
        Quis quibusdam libero molestiae reprehenderit quos repudiandae earum
        tempore est unde. Asperiores, consequuntur alias magni nisi aliquam
        animi repudiandae hic accusantium consequatur, laborum velit, veniam sed
        necessitatibus laboriosam natus obcaecati placeat incidunt nihil ea.
        Enim dicta porro excepturi molestiae, ipsam suscipit necessitatibus
        perferendis ratione ad explicabo aspernatur reiciendis. Maxime obcaecati
        autem adipisci alias, porro temporibus laudantium ratione, possimus
        assumenda beatae illum aut animi, labore perferendis. Laborum, vel
        repellendus modi eveniet labore esse, facilis accusamus hic possimus,
        ipsam deserunt recusandae id. Dolore nemo harum rem eum. Ea ullam quis,
        repellat ad a suscipit corrupti animi cumque id fuga molestias magni est
        pariatur quas unde ab vitae optio, maiores vel eos rerum! Dolorum iure
        quam cum quod quibusdam in consequatur voluptas quidem sit illo libero
        voluptatem voluptatum tempora tempore illum iusto sapiente unde, itaque
        officiis nesciunt fuga assumenda! Aut fugit placeat repellat accusamus
        quo qui earum cupiditate.
      </p>
    </div>
  );
}

export default Home;
