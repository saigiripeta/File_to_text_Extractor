import React from "react";

function PageNotFound() {
  return (
    <div style={{ textAlign: "center", marginTop: "30px" }}>
      <img
        src="https://kinsta.com/wp-content/uploads/2020/10/page-not-found.png"
        width={1000}
        height={400}
      />
    </div>
  );
}

export default PageNotFound;
