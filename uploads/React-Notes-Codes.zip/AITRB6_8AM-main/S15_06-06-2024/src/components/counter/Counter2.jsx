import React from "react";

function Counter2() {
  return <div>Counter2</div>;
}

export default Counter2;
