import Header from "./components/header/Header";
import Counter from "./components/counter/Counter";
import "./App.css";

function App() {
  return (
    <div className="app">
      <Counter />
      {/* <h2>App Component</h2> */}
      {/* <Header /> */}
    </div>
  );
}

export default App;
