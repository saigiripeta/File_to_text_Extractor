import "./Header.css";
function Header() {
  return (
    <div className="header">
      <h2 style={{ color: "white" }}>Header Component</h2>
    </div>
  );
}

export default Header;
