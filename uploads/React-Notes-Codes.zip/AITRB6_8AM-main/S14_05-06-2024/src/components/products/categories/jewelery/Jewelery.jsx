import React from "react";

function Jewelery() {
  return (
    <div>
      <h2>Jewelery Component</h2>
    </div>
  );
}

export default Jewelery;
