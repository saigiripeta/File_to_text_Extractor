import React from "react";

function Electronics() {
  return (
    <div>
      <h2>Electronics Component</h2>
    </div>
  );
}

export default Electronics;
