import React from "react";

function Home() {
  return (
    <div style={{ padding: "50px" }}>
      <h2 style={{ color: "green" }}>Home Component</h2>
      <br />
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam, autem
        similique. Sed aspernatur eaque molestias ipsum! Aliquid commodi quod
        eius, nam minima molestiae. Saepe hic dolores deserunt. Ad expedita
        dolores velit dolor eius dicta placeat inventore temporibus. Voluptatem
        totam officia cumque maiores est. Provident tenetur numquam excepturi
        laborum dolore? Voluptates, minima. Pariatur laborum dolor voluptatem.
        Quis quibusdam libero molestiae reprehenderit quos repudiandae earum
        tempore est unde. Asperiores, consequuntur alias magni nisi aliquam
        animi repudiandae hic accusantium consequatur, laborum velit, veniam sed
        necessitatibus laboriosam natus obcaecati placeat incidunt nihil ea.
        Enim dicta porro excepturi molestiae, ipsam suscipit necessitatibus
        perferendis ratione ad explicabo aspernatur reiciendis. Maxime obcaecati
        autem adipisci alias, porro temporibus laudantium ratione, possimus
        assumenda beatae illum aut animi, labore perferendis. Laborum, vel
        repellendus modi eveniet labore esse, facilis accusamus hic possimus,
        ipsam deserunt recusandae id. Dolore nemo harum rem eum. Ea ullam quis,
        repellat ad a suscipit corrupti animi cumque id fuga molestias magni est
        pariatur quas unde ab vitae optio, maiores vel eos rerum! Dolorum iure
        quam cum quod quibusdam in consequatur voluptas quidem sit illo libero
        voluptatem voluptatum tempora tempore illum iusto sapiente unde, itaque
        officiis nesciunt fuga assumenda! Aut fugit placeat repellat accusamus
        quo qui earum cupiditate.
      </p>
      <br />
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati
        voluptates eos deserunt eveniet nostrum perspiciatis doloremque, omnis
        cum, harum recusandae natus labore, rem at ut? Labore repellat quae,
        dicta cumque magnam omnis perferendis itaque accusamus, amet explicabo
        ut dolorem aut cupiditate laudantium, veniam ea placeat sequi quo
        voluptatem. Animi maxime iusto voluptatum autem vitae laborum, facilis
        id earum dolor accusamus explicabo itaque cumque ipsum quasi expedita
        adipisci fugit natus velit molestiae voluptates voluptas quia tempora
        minus asperiores! Explicabo dolore laborum deserunt quos, temporibus
        cumque repellendus veritatis reiciendis corporis amet ipsa minus ex
        molestiae ducimus error fuga hic sit unde odit. Soluta, porro nisi?
        Labore laudantium unde ipsa harum! Ullam ad, sint ex distinctio
        molestias quasi consectetur officia. Repellat ipsum nulla, repudiandae
        explicabo adipisci quidem quibusdam ab saepe culpa accusantium
        laboriosam magni, vero maiores porro. Repellat libero voluptates totam
        aliquam culpa, ratione dignissimos corrupti in voluptas minus rerum
        suscipit deserunt omnis nulla non architecto iusto eligendi dolor
        provident. Laborum dolor doloribus quos rerum tempore harum magnam
        debitis fuga perspiciatis sequi, itaque ab maxime repudiandae reiciendis
        voluptate, porro aperiam perferendis? Obcaecati facilis maxime animi.
        Nostrum quibusdam tenetur culpa dolorem ducimus eaque assumenda,
        reprehenderit quam ipsam tempora nemo, at libero quasi eius est fugit
        esse. Maxime esse quisquam excepturi ipsum, voluptate magnam quo fuga
        facilis magni odio, iste facere repellendus suscipit accusamus, dolore
        perspiciatis vitae consequuntur unde dolorum dignissimos? Illum,
        sapiente ex. Quasi itaque dolor fugit possimus esse accusamus tenetur
        adipisci quas maiores a mollitia facere sequi velit reprehenderit harum
        eligendi quia, commodi soluta at alias ut quidem! Voluptatem, alias non!
        Dicta similique quo, ex voluptas, recusandae nemo provident itaque
        aperiam alias, iusto necessitatibus temporibus officia vero error
        nesciunt blanditiis eum ipsam quasi a odio doloribus vitae. Perspiciatis
        laudantium vel, aut blanditiis mollitia repudiandae quos nisi fugiat
        dicta quibusdam odit ipsam praesentium illo officiis pariatur aliquid ab
        nam tempora excepturi tempore consequatur omnis! Fuga minus excepturi,
        dolorem eos vero alias? Explicabo, adipisci aspernatur? Illum mollitia
        perspiciatis est minima autem officiis ratione, eum architecto, id optio
        totam obcaecati consequuntur magni eaque assumenda. Ad mollitia
        provident exercitationem eligendi in ut eius, animi corporis blanditiis,
        officia molestias esse ullam molestiae quasi, vitae dolore excepturi
        voluptas. Natus exercitationem dolore labore atque omnis velit maxime,
        suscipit recusandae repellat libero quis repellendus officiis magni hic
        similique, laboriosam qui deserunt earum! Sit perspiciatis consequuntur
        velit libero, nemo dolor ut nihil ad quaerat, architecto neque commodi
        nisi sequi omnis magni? Quam.
      </p>
    </div>
  );
}

export default Home;
