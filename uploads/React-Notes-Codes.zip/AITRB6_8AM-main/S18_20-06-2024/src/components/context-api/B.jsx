import React from "react";
import C from "./C";
function B() {
  return (
    <div style={{ padding: "10px" }}>
      <h2>B Component</h2>

      <br />
      <hr />
      <C />
    </div>
  );
}

export default B;
