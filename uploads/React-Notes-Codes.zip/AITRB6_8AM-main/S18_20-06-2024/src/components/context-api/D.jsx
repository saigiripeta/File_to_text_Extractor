import React from "react";
import E from "./E";
function D() {
  return (
    <div style={{ padding: "10px" }}>
      <h2>D Component</h2>

      <br />
      <hr />
      <E />
    </div>
  );
}

export default D;
