import { createContext } from "react";

let myfirstContext = createContext();

export default myfirstContext;
