import React from "react";

function E({ info }) {
  return (
    <div>
      <h2>E Comp</h2>
      <br />
      <h3>Data: {info}</h3>
    </div>
  );
}

export default E;
