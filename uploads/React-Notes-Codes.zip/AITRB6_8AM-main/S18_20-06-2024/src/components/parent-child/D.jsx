import React from "react";
import E from "./E";
function D({ info }) {
  return (
    <div>
      <h2>D Comp</h2>
      <hr />
      <E info={info} />
    </div>
  );
}

export default D;
