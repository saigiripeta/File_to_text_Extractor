import { createContext } from "react";

export let myHomeContext = createContext();
